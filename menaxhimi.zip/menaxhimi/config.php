<?php
$host = 'localhost';     // Hosti i bazës së të dhënave (për shembull, localhost)
$dbname = 'menaxhimi';   // Emri i bazës së të dhënave
$username = 'root';      // Emri i përdoruesit për MySQL (default: 'root' për XAMPP)
$password = '';          // Fjalëkalimi (default: '' për XAMPP)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Gabim lidhjeje: " . $e->getMessage());
}
?>
