<?php
session_start();

// Kontrollojmë nëse përdoruesi është loguar dhe është admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Përdorimi i lidhjes me bazën e të dhënave
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Marrim të dhënat nga formulari
    $title = $_POST['title'];
    $description = $_POST['description'];
    $user_id = $_POST['user_id']; // Përdoruesi përkatës që do të caktohet detyra
    $status = 'pending'; // Statusi fillestar është 'pending'
    $start_time = date('Y-m-d H:i:s'); // Ora e fillimit (kur detyra krijohet)

    // Kontrollohet nëse të dhënat janë të plota
    if (!empty($title) && !empty($description) && !empty($user_id)) {
        // Shtimi i detyrës në bazë të të dhënave
        $stmt = $pdo->prepare("INSERT INTO tasks (title, description, user_id, status, start_time) 
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $description, $user_id, $status, $start_time]);

        // Pas shtimit, redirektojmë përdoruesin në faqen e detyrave
        header("Location: index.php");  // Redirektohet pas dërgimit të suksesshëm
        exit; // Sigurohemi që nuk do të bëhet më asgjë tjetër pas redirektimit
    } else {
        echo "Të gjitha fushat duhet të plotësohen.";
    }
}
?>

<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shto Detyrë</title>
</head>
<body>
    <h1>Shto Detyrë të Re</h1>
    
    <form method="POST" action="create_task.php">
        <label for="title">Titulli i Detyrës:</label><br>
        <input type="text" id="title" name="title" required><br><br>

        <label for="description">Përshkrimi i Detyrës:</label><br>
        <textarea id="description" name="description" required></textarea><br><br>

        <label for="user_id">Zgjedh Punonjës:</label><br>
        <select name="user_id" id="user_id">
            <?php
            // Kjo është për të marrë përdoruesit që kanë rol 'employee'
            $stmt = $pdo->prepare("SELECT id, name FROM users WHERE role = 'employee'");
            $stmt->execute();
            $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($employees as $employee) {
                echo "<option value='" . $employee['id'] . "'>" . $employee['name'] . "</option>";
            }
            ?>
        </select><br><br>

        <button type="submit">Shto Detyrën</button>
    </form>

    <a href="index.php">Kthehu në Detyrat</a>
</body>
</html>
