<?php
session_start();

// Kontrollojmë nëse përdoruesi është loguar dhe është admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Përdorimi i lidhjes me bazën e të dhënave
include('config.php');

// Përcaktimi i id-së së përdoruesit dhe rolit nga sesioni
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];  // Roli i përdoruesit (mund të jetë 'admin' ose 'employee')

// Inicializimi i variablës për detyrat
$tasks = [];

// Mënyra e kërkimit të detyrave në bazën e të dhënave
if ($role == 'admin') {
    // Administratori mund të shohë të gjitha detyrat
    $stmt = $pdo->prepare("SELECT * FROM tasks");
    $stmt->execute();
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Përdoruesit për secilin punonjës
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE role = 'employee'");
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Punonjësi mund të shohë vetëm detyrat e tij
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menaxhimi i Detyrave</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Menaxhimi i Detyrave</h1>

    <?php if ($role == 'admin'): ?>
        <!-- Kjo mundësi shfaqet vetëm për administratori -->
        <h2>Shto Detyrë të Re</h2>
        <a href="create_task.php">Kliko këtu për të shtuar një detyrë të re</a>
    <?php endif; ?>

    <h2>Detyrat Tuaja</h2>
    <ul>
        <?php if (!empty($tasks)): ?>
            <?php foreach ($tasks as $task): ?>
                <li>
                    <strong><?php echo htmlspecialchars($task['title']); ?></strong><br>
                    <?php echo htmlspecialchars($task['description']); ?><br>
                    Status: <?php echo htmlspecialchars($task['status']); ?><br>
                    Ora e fillimit: <?php echo $task['start_time'] ? date('Y-m-d H:i:s', strtotime($task['start_time'])) : 'Nuk ka filluar akoma'; ?><br>
                    Ora e përfundimit: <?php echo $task['end_time'] ? date('Y-m-d H:i:s', strtotime($task['end_time'])) : 'Ende nuk është përfunduar'; ?><br>

                    <?php if ($role == 'employee' && $task['status'] == 'pending'): ?>
                        <!-- Butoni për përfundimin e detyrës (për punonjësit) -->
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                            <input type="hidden" name="status" value="completed">
                            <button type="submit">Perfundo Detyrën</button>
                        </form>
                    <?php endif; ?>

                    <?php if ($role == 'admin'): ?>
                        <!-- Butoni për fshirjen e detyrës (për admin) -->
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="delete_task_id" value="<?php echo $task['id']; ?>">
                            <button type="submit" onclick="return confirm('Jeni të sigurt që doni të fshini këtë detyrë?')">Fshi Detyrën</button>
                        </form>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Ende nuk ka detyra.</p>
        <?php endif; ?>
    </ul>

    <a href="logout.php">Log Out</a>
</body>
</html>
