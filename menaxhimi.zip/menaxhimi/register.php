<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('config.php');

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role'];

    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $email, $password, $role]);

    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="sq">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regjistrohu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Regjistrohu</h1>
    <form method="POST">
        <label>Emri:</label><br>
        <input type="text" name="name" required><br>
        <label>Email:</label><br>
        <input type="email" name="email" required><br>
        <label>Fjalëkalimi:</label><br>
        <input type="password" name="password" required><br>
        <label>Roli:</label><br>
        <select name="role">
            <option value="employee">Punonjës</option>
            <option value="admin">Administrator</option>
        </select><br><br>
        <button type="submit">Regjistrohu</button>
    </form>
</body>
</html>
