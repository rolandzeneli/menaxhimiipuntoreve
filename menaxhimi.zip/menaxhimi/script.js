document.addEventListener("DOMContentLoaded", function() {
    fetchTasks();

    document.getElementById("task-form").addEventListener("submit", function(e) {
        e.preventDefault();
        const title = document.getElementById("title").value;
        const description = document.getElementById("description").value;
        const due_date = document.getElementById("due_date").value;
        const status = document.getElementById("status").value;

        fetch("create_task.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: `user_id=1&title=${title}&description=${description}&status=${status}&due_date=${due_date}`
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            fetchTasks();
        });
    });
});

function fetchTasks() {
    fetch("get_tasks.php?user_id=1")
        .then(response => response.json())
        .then(tasks => {
            const tasksContainer = document.getElementById("tasks-container");
            tasksContainer.innerHTML = "";
            tasks.forEach(task => {
                const taskElement = document.createElement("div");
                taskElement.classList.add("task");
                taskElement.innerHTML = `
                    <h3>${task.title}</h3>
                    <p>${task.description}</p>
                    <p>Statusi: ${task.status}</p>
                    <p>Data e Skadencës: ${task.due_date}</p>
                    <button onclick="updateTaskStatus(${task.id}, 'completed')">Përfunduar</button>
                `;
                tasksContainer.appendChild(taskElement);
            });
        });
}

function updateTaskStatus(taskId, status) {
    fetch("update_task.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `task_id=${taskId}&status=${status}`
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        fetchTasks();
    });
}
